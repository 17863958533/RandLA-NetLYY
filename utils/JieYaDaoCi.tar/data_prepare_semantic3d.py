# import sys
# sys.path.append('/home/pc/anaconda3/envs/tf26lyy/lib')

from sklearn.neighbors import KDTree
from os.path import join, exists, dirname, abspath
import numpy as np
import os, glob, pickle
import sys

BASE_DIR = dirname(abspath(__file__))
ROOT_DIR = dirname(BASE_DIR)
sys.path.append(BASE_DIR)
sys.path.append(ROOT_DIR)
from helper_ply import write_ply
from helper_tool import DataProcessing as DP

import open3d as o3d
from tqdm import tqdm

grid_size = 0.03
#dataset_path = '/data/semantic3d/original_data'
dataset_path = '/media/pc/C8BE4D94BE4D7BC6/data/LYYData/original_data'
original_pc_folder = join(dirname(dataset_path), 'original_ply')
sub_pc_folder = join(dirname(dataset_path), 'input_{:.3f}'.format(grid_size))
os.mkdir(original_pc_folder) if not exists(original_pc_folder) else None
os.mkdir(sub_pc_folder) if not exists(sub_pc_folder) else None

for pc_path in glob.glob(join(dataset_path, '*.txt')):
    print(pc_path)
    file_name = pc_path.split('/')[-1][:-4]

    # check if it has already calculated
    if exists(join(sub_pc_folder, file_name + '_KDTree.pkl')):
        continue

    pc = DP.load_pc_semantic3d(pc_path)

    # ----------我自己写的代码。用于对齐pc这个数据里面的格式为xyzrgbl-----
    # data_list = []
    # # 使用进度条读取txt文件并将数据添加到列表中
    # with open(pc_path, 'r') as file:
    #     num_lines = sum(1 for line in file)
    #     file.seek(0)  # 将文件指针重新定位到文件开头
    #     for line in tqdm(file, total=num_lines, desc='Loading data', unit=' lines'):
    #         # 按空格分割行，并将数据转换为浮点数
    #         parts = line.strip().split()
    #         data_list.append([float(part) for part in parts])
    #
    # # 将数据列表转换为NumPy数组
    # data = np.array(data_list)
    # pc = data
    # ------------------------------------------------------------

    # check if label exists
    label_path = pc_path[:-4] + '.labels'
    if exists(label_path):
        labels = DP.load_label_semantic3d(label_path)
        full_ply_path = join(original_pc_folder, file_name + '.ply')

        #  Subsample to save space
        sub_points, sub_colors, sub_labels = DP.grid_sub_sampling(pc[:, :3].astype(np.float32),
                                                                  pc[:, 3:6].astype(np.uint8), labels, 0.01)     #按照0.01的距离进行第一次格网下采样！！！
        sub_labels = np.squeeze(sub_labels)

        write_ply(full_ply_path, (sub_points, sub_colors, sub_labels), ['x', 'y', 'z', 'red', 'green', 'blue', 'class'])

        # save sub_cloud and KDTree file
        sub_xyz, sub_colors, sub_labels = DP.grid_sub_sampling(sub_points, sub_colors, sub_labels, grid_size)     #按照0.06的距离进行第2次格网下采样,这部分数值在本程序的一开头就定义了0.06,该部分值可以根据自己的数据他特点进行调整！！！

        # 颜色归一化
        sub_colors = sub_colors / 255.0
        sub_labels = np.squeeze(sub_labels)
        # 保存第二次下采样结果
        sub_ply_file = join(sub_pc_folder, file_name + '.ply')
        write_ply(sub_ply_file, [sub_xyz, sub_colors, sub_labels], ['x', 'y', 'z', 'red', 'green', 'blue', 'class'])

        # 建立kdtree
        search_tree = KDTree(sub_xyz, leaf_size=50)
        kd_tree_file = join(sub_pc_folder, file_name + '_KDTree.pkl')
        # 保存kdtree
        with open(kd_tree_file, 'wb') as f:
            pickle.dump(search_tree, f)
        # 使用kdtree查询距离第二次下采样后的点距离第一次下采样后的点的最近点的序号（第二次下采样的点的序号）
        proj_idx = np.squeeze(search_tree.query(sub_points, return_distance=False))
        proj_idx = proj_idx.astype(np.int32)
        proj_save = join(sub_pc_folder, file_name + '_proj.pkl')
        with open(proj_save, 'wb') as f:
            pickle.dump([proj_idx, labels], f)

    else:
        # semantic3d的测试数据集每个给出标签，这里的操作跟有标签文件差不多是一致的。
        full_ply_path = join(original_pc_folder, file_name + '.ply')
        write_ply(full_ply_path, (pc[:, :3].astype(np.float32), pc[:, 4:7].astype(np.uint8)),
                  ['x', 'y', 'z', 'red', 'green', 'blue'])

        # save sub_cloud and KDTree file
        sub_xyz, sub_colors = DP.grid_sub_sampling(pc[:, :3].astype(np.float32), pc[:, 4:7].astype(np.uint8),
                                                   grid_size=grid_size)
        sub_colors = sub_colors / 255.0
        sub_ply_file = join(sub_pc_folder, file_name + '.ply')
        write_ply(sub_ply_file, [sub_xyz, sub_colors], ['x', 'y', 'z', 'red', 'green', 'blue'])
        labels = np.zeros(pc.shape[0], dtype=np.uint8)

        search_tree = KDTree(sub_xyz, leaf_size=50)
        kd_tree_file = join(sub_pc_folder, file_name + '_KDTree.pkl')
        with open(kd_tree_file, 'wb') as f:
            pickle.dump(search_tree, f)

        proj_idx = np.squeeze(search_tree.query(pc[:, :3].astype(np.float32), return_distance=False))
        proj_idx = proj_idx.astype(np.int32)
        proj_save = join(sub_pc_folder, file_name + '_proj.pkl')
        with open(proj_save, 'wb') as f:
            pickle.dump([proj_idx, labels], f)
